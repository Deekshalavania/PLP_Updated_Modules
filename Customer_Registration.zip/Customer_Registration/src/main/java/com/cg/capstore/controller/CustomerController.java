package com.cg.capstore.controller;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerdoesnotExist;
import com.cg.capstore.service.ICustomerProfileChangeSercvice;

@Controller
public class CustomerController {

	@Autowired
	ICustomerProfileChangeSercvice service;

	
	@RequestMapping("/")
	public String hello() {
		return "customer";
	}
	

	@RequestMapping(value="/profile")
	public String changeProfile(){
		return "profile";
	}
	
	
	@RequestMapping("/change")
	public String change(Customer customer) throws CustomerdoesnotExist {
		service.changeProfile(customer);
		return "sucess";
	}
	
}
