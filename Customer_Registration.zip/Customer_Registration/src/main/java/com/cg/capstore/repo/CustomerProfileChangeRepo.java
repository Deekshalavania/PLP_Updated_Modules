package com.cg.capstore.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerdoesnotExist;

@Transactional
@Repository
public class CustomerProfileChangeRepo implements ICustomerProfileChangeRepo{

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public Customer changeProfile(Customer customer) throws CustomerdoesnotExist {
		Customer profile=entity.find(Customer.class,customer.getCustomerMobileNo());
		profile.setName(customer.getName());
		profile.setEmail(customer.getEmail());
		profile.setPassword(customer.getPassword());
		return profile;
			
	}
}
