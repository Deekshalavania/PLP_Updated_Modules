package com.cg.capstore.repo;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerdoesnotExist;


public interface ICustomerProfileChangeRepo {
	
	Customer changeProfile(Customer customer) throws CustomerdoesnotExist;

	}
